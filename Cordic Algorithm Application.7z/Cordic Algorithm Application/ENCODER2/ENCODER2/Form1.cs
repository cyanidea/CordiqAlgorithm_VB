﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using S7.Net;

namespace ENCODER2
{
    public partial class Form1 : Form
    {
        private Plc plc = null;
        string Value_Read = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.DataSource = Enum.GetValues(typeof(CpuType));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CpuType cpu = (CpuType)Enum.Parse(typeof(CpuType),comboBox1.Text);
            plc = new Plc(cpu, textBox1.Text, Convert.ToInt16(textBox2.Text), Convert.ToInt16(textBox3.Text));
            plc.Open();

            if (plc.IsConnected)
            {
                label5.Text = "PLC Connected";
                timer1.Enabled = true;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            object result = plc.Read("DB2.DBD20"); //.ConvertToFloat();
            Value_Read = ((uint)result).ToString();
            label6.Text = Value_Read;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            plc.Write("DB2.DBX24.0", true); 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            plc.Write("DB2.DBX24.0", false);
        }
    }
}
