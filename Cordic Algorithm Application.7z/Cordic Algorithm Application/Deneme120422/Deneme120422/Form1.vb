﻿Public Class Form1
    'I wanna Disable buttons before login
    Sub IsButtonEnabled(EnBool As Boolean)
        Button1.Enabled = EnBool
        Button2.Enabled = EnBool
        Button3.Enabled = EnBool
    End Sub
    'NavigatePage Subroutine, Sub do not return value diff. with func
    Sub NavigateMenu(OpenedPage As Form)
        Panel2.Controls.Clear()
        OpenedPage.TopLevel = False
        Panel2.Controls.Add(OpenedPage)
        OpenedPage.Show()
    End Sub
    'Initilialize Form1 Load
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        IsButtonEnabled(False)
    End Sub
    'Notify Button
    Dim Notify As Boolean = True
    Private Sub ButtonHide_Click(sender As Object, e As EventArgs) Handles ButtonNotify.Click
        If Notify = True Then
            NotifyIcon1.Visible = False
            Notify = False
            ButtonNotify.Text = "Show the Notify Icon"
            'NotifyIcon1.BalloonTipIcon = ToolTipIcon.Info
            'NotifyIcon1.BalloonTipTitle = "Status"
            'NotifyIcon1.BalloonTipText = "Show the Notify Icon"
            'NotifyIcon1.ShowBalloonTip(2000)
        Else
            NotifyIcon1.Visible = True
            Notify = True
            ButtonNotify.Text = "Hide the Notify Icon"
        End If
    End Sub
    'Notify Exit
    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        'Application.Exit()
        Me.Close()
    End Sub

    'Exit Button:
    Private Sub ButtonExit_Click(sender As Object, e As EventArgs) Handles ButtonExit.Click
        Application.Exit()
    End Sub
    'Button1,2,3::
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        NavigateMenu(Page1)
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        NavigateMenu(Page2)
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        NavigateMenu(Page3)
    End Sub
    'Login Button:
    Private Sub ButtonLogin_Click(sender As Object, e As EventArgs) Handles ButtonLogin.Click
        If TextBoxUserID.Text = "Admin" And TextBoxPassword.Text = "1234" Then
            MsgBox("You Login Sucessfully")
            IsButtonEnabled(True)
        Else
            MsgBox("Wrong Password")
        End If
    End Sub
End Class
