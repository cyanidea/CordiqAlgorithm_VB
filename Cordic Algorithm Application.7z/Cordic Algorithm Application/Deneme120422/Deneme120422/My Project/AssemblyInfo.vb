﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Bir bütünleştirilmiş koda ilişkin Genel Bilgiler aşağıdaki öznitelikler kümesiyle
' denetlenir. Bütünleştirilmiş kod ile ilişkili bilgileri değiştirmek için
' bu öznitelik değerlerini değiştirin.

' Bütünleştirilmiş kod özniteliklerinin değerlerini gözden geçirin

<Assembly: AssemblyTitle("Deneme120422")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("Deneme120422")>
<Assembly: AssemblyCopyright("Copyright ©  2022")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'Bu proje COM'un kullanımına sunulursa aşağıdaki GUID, typelib kimliği içindir
<Assembly: Guid("b3f70fa9-c5dd-4feb-8690-bde22565c40a")>

' Bir derlemenin sürüm bilgileri aşağıdaki dört değerden oluşur:
'
'      Ana Sürüm
'      İkincil Sürüm 
'      Yapı Numarası
'      Düzeltme
'
' Tüm değerleri belirtebilir veya varsayılan Derleme ve Düzeltme Numaralarını kullanmak için
' aşağıda gösterildiği gibi '*' kullanabilirsiniz:
' <Assembly: AssemblyVersion("1.0.*")>

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
