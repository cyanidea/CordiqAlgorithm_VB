﻿Public Class Form1
    Dim DGT1IndexCounter As Integer = 0     '1st Data Grid Last Index Counter
    Dim DGT23IndexCounter As Integer = 0    '2nd & 3rd Data Grid Last Index Counter
    Sub Determine_Angle_Region(ByVal _i As Decimal, ByVal _cos As Decimal, ByVal _sin As Decimal, ByVal _tan As Decimal, ByVal _ErrQ As Decimal, ByVal _Q As Decimal)
        If ((Math.Abs(_Q)) Mod 360 <= 90) Then          'If angle in Region 1, Create Data Grid accordingly.
            Me.DataGridView1.Rows.Add(_i, _cos, _sin, _tan, _ErrQ)
        ElseIf ((Math.Abs(_Q)) Mod 360 <= 180) Then     'If angle in Region 2, carry the results.
            Me.DataGridView1.Rows.Add(_i, -(_sin), _cos, -(1 / (_tan)), _ErrQ)
        ElseIf ((Math.Abs(_Q)) Mod 360 <= 270) Then     'If angle in Region 3...
            Me.DataGridView1.Rows.Add(_i, -(_cos), -(_sin), _tan, _ErrQ)
        Else                                            'If angle in Region 4..
            Me.DataGridView1.Rows.Add(_i, _sin, -(_cos), _tan, _ErrQ)
        End If
    End Sub

    Function Calculate_Error(ByVal _X As Decimal, ByVal _Y As Decimal, ByVal _QR1 As Decimal, ByVal _Q As Decimal) As Boolean
        Dim CosRealR1, SinRealR1, CosErr, SinErr As Decimal
        Dim CosReal, SinReal As Decimal

        CosReal = Math.Cos((_Q) * (Math.PI) / 180)      'Actual Cos(Q) Value
        SinReal = Math.Sin((_Q) * (Math.PI) / 180)      'Actual Sin(Q) Value

        CosRealR1 = Math.Cos((_QR1) * (Math.PI) / 180)  'Actual Cos(Q) Value for Q in R1
        SinRealR1 = Math.Sin((_QR1) * (Math.PI) / 180)  'Actual Sin(Q) Value for Q in R1

        CosErr = Math.Abs(CosRealR1 - (_X)) * (10 ^ 7)  'Difference of Actual & Real Trig... 
        SinErr = Math.Abs(SinRealR1 - (_Y)) * (10 ^ 7)  'Value * (10^7) for cos and sin values

        If (CBool(CosErr < 2) And CBool(SinErr < 2)) Then   'Is error acceptable?
            Me.DataGridView2.Rows.Add("For: " + CStr(_Q) + " Degree", CosReal, SinReal, (SinReal / CosReal), "(Result From Math Library)")
            Me.DataGridView3.Rows.Add("For: " + CStr(_Q) + " Degree", CosErr, SinErr, "No", "Deflection in (1/500.000)")
            Return True
        Else
            Return False
        End If
    End Function

    Sub Implement_Cordic()
        Dim Tolerance_Acceptable As Boolean

        Dim inp As Decimal = TextBox1.Text  'Take an Angle from user
        Dim inpR1 As Decimal = inp Mod 90   'Carry the angle first Region

        Dim i, j, sigma As Integer          'XX,YY is an array of 499 Decimals'
        Dim XX(499), YY(499), ZZ(499), ErrQ(499), AngleDer(499) As Decimal

        XX(0) = 0.607253031529134           '1 * Cordic Gain For Xi, CosQi
        YY(0) = 0.607253031529134           '1 * Cordic Gain For Yi, SinQi
        ZZ(0) = YY(0) / XX(0)               'TanQi
        AngleDer(0) = 45                    'Qi0 = 45 degree
        ErrQ(0) = inpR1 - AngleDer(0)       'Calculate Error Angle

        Determine_Angle_Region(0, XX(0), YY(0), ZZ(0), ErrQ(0), inp)

        For i = 1 To 499                    'Calculate Cordic iterations in...
            j = i - 1                       ' ..each cycle of for loop

            AngleDer(i) = (Math.Atan((1 / (2 ^ (i))))) * (180 / Math.PI)

            If (ErrQ(j) < 0) Then           'Converge 0 to with negative...
                ErrQ(i) = ErrQ(j) + AngleDer(i)
                sigma = -1
            Else                            ' ...or positive sigma value
                ErrQ(i) = ErrQ(j) - AngleDer(i)
                sigma = 1
            End If

            XX(i) = (XX(j) - ((sigma) * ((2 ^ (-1 * i)) * YY(j))))
            YY(i) = (YY(j) + ((sigma) * ((2 ^ (-1 * i)) * XX(j))))
            ZZ(i) = (YY(i) / XX(i))

            Tolerance_Acceptable = Calculate_Error(XX(i), YY(i), inpR1, inp)
            If (Tolerance_Acceptable = True) Then   'End iterations if...
                Exit For                            '...tolerance acceptable
            End If

            Determine_Angle_Region(i, XX(i), YY(i), ZZ(i), ErrQ(i), inp)
            DGT1IndexCounter += 1
        Next i
        DataGridView1.Rows(DGT1IndexCounter).DefaultCellStyle.BackColor = Color.Yellow
    End Sub
    'in case of pressing the button one, respectively,
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Implement_Cordic()
        DGT1IndexCounter += 1

        DataGridView2.Rows(DGT23IndexCounter).DefaultCellStyle.BackColor = Color.Green
        DataGridView3.Rows(DGT23IndexCounter).DefaultCellStyle.BackColor = Color.Red
        DGT23IndexCounter += 1
    End Sub
    'in case of pressing the button two, respectively,
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.DataGridView1.Rows.Clear()
        Me.DataGridView2.Rows.Clear()
        Me.DataGridView3.Rows.Clear()
        DGT1IndexCounter = 0
        DGT23IndexCounter = 0
    End Sub
End Class